abstract class CTCardData {
  String get imageUrl;
  String get name;
}