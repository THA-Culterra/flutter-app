

class CountryViewModel {
  // Function to get a country (example: Algeria)

}
