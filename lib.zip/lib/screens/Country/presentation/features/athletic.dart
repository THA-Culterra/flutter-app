import 'package:flutter/material.dart';

import '../../data/models/athletics.dart';

class AthleticScreen extends StatelessWidget {
  const AthleticScreen({super.key, required this.athletics});

  final Athletics athletics;

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
