import 'package:flutter/material.dart';

import '../../data/models/cinema.dart';

class CinemaScreen extends StatelessWidget {
  const CinemaScreen({super.key, required this.cinema});

  final Cinema cinema;

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
