// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'taxi_app.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TaxiApp _$TaxiAppFromJson(Map<String, dynamic> json) =>
    TaxiApp(name: json['name'] as String, imageUrl: json['imageUrl'] as String);

Map<String, dynamic> _$TaxiAppToJson(TaxiApp instance) => <String, dynamic>{
  'name': instance.name,
  'imageUrl': instance.imageUrl,
};
