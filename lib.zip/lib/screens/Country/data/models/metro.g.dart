// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'metro.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Metro _$MetroFromJson(Map<String, dynamic> json) =>
    Metro(city: json['city'] as String, image: json['image'] as String);

Map<String, dynamic> _$MetroToJson(Metro instance) => <String, dynamic>{
  'city': instance.city,
  'image': instance.image,
};
