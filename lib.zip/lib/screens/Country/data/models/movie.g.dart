// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'movie.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Movie _$MovieFromJson(Map<String, dynamic> json) =>
    Movie(name: json['name'] as String, image: json['image'] as String);

Map<String, dynamic> _$MovieToJson(Movie instance) => <String, dynamic>{
  'name': instance.name,
  'image': instance.image,
};
