// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'genre.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Genre _$GenreFromJson(Map<String, dynamic> json) =>
    Genre(name: json['name'] as String, imageUrl: json['imageUrl'] as String);

Map<String, dynamic> _$GenreToJson(Genre instance) => <String, dynamic>{
  'name': instance.name,
  'imageUrl': instance.imageUrl,
};
