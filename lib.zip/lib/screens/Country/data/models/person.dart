abstract class Person {
  String get name;
  int get age;
}