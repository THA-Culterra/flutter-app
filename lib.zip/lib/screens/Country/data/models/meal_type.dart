enum MealType {
  breakfast,
  lunch,
  dinner,
  dessert
}