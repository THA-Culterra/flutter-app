enum Religion {
  islam,
  christianity,
  judaism,
  hinduism
}