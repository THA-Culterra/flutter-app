enum DrivingSide {
  left,
  right
}