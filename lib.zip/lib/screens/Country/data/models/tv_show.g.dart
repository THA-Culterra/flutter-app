// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tv_show.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TvShow _$TvShowFromJson(Map<String, dynamic> json) =>
    TvShow(name: json['name'] as String, image: json['image'] as String);

Map<String, dynamic> _$TvShowToJson(TvShow instance) => <String, dynamic>{
  'name': instance.name,
  'image': instance.image,
};
