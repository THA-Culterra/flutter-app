enum Role {
  explorer,
  cuisine,
  music,
  cinema,
  history,
  sports,
  transport,
  emergency,
}