abstract class TvProgram {
  String get name;
  String get image;
}